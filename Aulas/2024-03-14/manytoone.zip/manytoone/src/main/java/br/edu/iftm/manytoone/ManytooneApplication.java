package br.edu.iftm.manytoone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManytooneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManytooneApplication.class, args);
	}

}
